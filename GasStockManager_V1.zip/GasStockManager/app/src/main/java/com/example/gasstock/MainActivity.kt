package com.example.gasstock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Product(val name: String, var full: Int = 0, var empty: Int = 0)
data class Vehicle(val name: String, var full: Int = 0, var empty: Int = 0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GasStockApp() }
    }
}

@Composable
fun GasStockApp() {
    var tab by remember { mutableStateOf("Dashboard") }
    val products = remember {
        mutableStateListOf(
            Product("Product 01"), Product("Product 02"), Product("Product 03"),
            Product("Product 04"), Product("Product 05"), Product("Product 06"),
            Product("Product 07"), Product("Product 08"), Product("Product 09"),
            Product("Product 10"), Product("Product 11"), Product("Product 12"),
            Product("Product 13"), Product("Product 14"), Product("Product 15"),
            Product("Product 16"), Product("Product 17")
        )
    }
    val vehicles = remember {
        mutableStateListOf(
            Vehicle("Vehicle 1"), Vehicle("Vehicle 2"), Vehicle("Vehicle 3"),
            Vehicle("Vehicle 4"), Vehicle("Vehicle 5"), Vehicle("Vehicle 6")
        )
    }
    var selectedVehicle by remember { mutableStateOf(0) }
    var selectedProduct by remember { mutableStateOf(0) }
    var qty by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    fun number() = qty.toIntOrNull()?.coerceAtLeast(0) ?: 0

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Gas Stock Manager") }) },
            bottomBar = {
                NavigationBar {
                    listOf("Dashboard","Products","Purchase","Dispatch","Return").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {},
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
                if (message.isNotBlank()) {
                    Text(message, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                }
                when (tab) {
                    "Dashboard" -> Dashboard(products, vehicles)
                    "Products" -> ProductsScreen(products)
                    "Purchase" -> EntryScreen(
                        title = "Purchase Entry",
                        products = products,
                        vehicles = vehicles,
                        selectedProduct = selectedProduct,
                        selectedVehicle = selectedVehicle,
                        qty = qty,
                        onProduct = { selectedProduct = it },
                        onVehicle = { selectedVehicle = it },
                        onQty = { qty = it },
                        showVehicle = false,
                        button = "Add to Store",
                        onSave = {
                            val n = number()
                            products[selectedProduct].full += n
                            message = "Purchase saved: +$n full ${products[selectedProduct].name}"
                            qty = ""
                        }
                    )
                    "Dispatch" -> EntryScreen(
                        title = "Vehicle Dispatch",
                        products = products,
                        vehicles = vehicles,
                        selectedProduct = selectedProduct,
                        selectedVehicle = selectedVehicle,
                        qty = qty,
                        onProduct = { selectedProduct = it },
                        onVehicle = { selectedVehicle = it },
                        onQty = { qty = it },
                        showVehicle = true,
                        button = "Dispatch Full",
                        onSave = {
                            val n = number()
                            if (n <= products[selectedProduct].full) {
                                products[selectedProduct].full -= n
                                vehicles[selectedVehicle].full += n
                                message = "Dispatched $n to ${vehicles[selectedVehicle].name}"
                                qty = ""
                            } else message = "Not enough store full stock."
                        }
                    )
                    "Return" -> EntryScreen(
                        title = "Vehicle Return",
                        products = products,
                        vehicles = vehicles,
                        selectedProduct = selectedProduct,
                        selectedVehicle = selectedVehicle,
                        qty = qty,
                        onProduct = { selectedProduct = it },
                        onVehicle = { selectedVehicle = it },
                        onQty = { qty = it },
                        showVehicle = true,
                        button = "Return Empty",
                        onSave = {
                            val n = number()
                            if (n <= vehicles[selectedVehicle].full) {
                                vehicles[selectedVehicle].full -= n
                                vehicles[selectedVehicle].empty += n
                                products[selectedProduct].empty += n
                                message = "Return saved: $n empty from ${vehicles[selectedVehicle].name}"
                                qty = ""
                            } else message = "Vehicle does not have that many full cylinders."
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun Dashboard(products: List<Product>, vehicles: List<Vehicle>) {
    val full = products.sumOf { it.full }
    val empty = products.sumOf { it.empty }
    Text("Dashboard", style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Card(Modifier.weight(1f)) { Column(Modifier.padding(16.dp)) { Text("Store Full"); Text("$full") } }
        Card(Modifier.weight(1f)) { Column(Modifier.padding(16.dp)) { Text("Store Empty"); Text("$empty") } }
    }
    Spacer(Modifier.height(18.dp))
    Text("Vehicle Stock", style = MaterialTheme.typography.titleLarge)
    LazyColumn {
        items(vehicles) { v ->
            ListItem(headlineContent = { Text(v.name) },
                supportingContent = { Text("Full: ${v.full}   Empty: ${v.empty}") })
        }
    }
}

@Composable
fun ProductsScreen(products: List<Product>) {
    Text("Products (17)", style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(8.dp))
    LazyColumn {
        items(products) { p ->
            ListItem(headlineContent = { Text(p.name) },
                supportingContent = { Text("Full: ${p.full}   Empty: ${p.empty}") })
        }
    }
}

@Composable
fun EntryScreen(
    title: String,
    products: List<Product>,
    vehicles: List<Vehicle>,
    selectedProduct: Int,
    selectedVehicle: Int,
    qty: String,
    onProduct: (Int) -> Unit,
    onVehicle: (Int) -> Unit,
    onQty: (String) -> Unit,
    showVehicle: Boolean,
    button: String,
    onSave: () -> Unit
) {
    Text(title, style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(14.dp))
    Text("Product")
    products.forEachIndexed { i, p ->
        if (i == selectedProduct) Text("Selected: ${p.name}", style = MaterialTheme.typography.titleMedium)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(onClick = { onProduct((selectedProduct + products.size - 1) % products.size) }) { Text("Prev") }
        Button(onClick = { onProduct((selectedProduct + 1) % products.size) }) { Text("Next") }
    }
    if (showVehicle) {
        Spacer(Modifier.height(8.dp))
        Text("Vehicle: ${vehicles[selectedVehicle].name}")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { onVehicle((selectedVehicle + vehicles.size - 1) % vehicles.size) }) { Text("Prev") }
            Button(onClick = { onVehicle((selectedVehicle + 1) % vehicles.size) }) { Text("Next") }
        }
    }
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = qty, onValueChange = onQty, label = { Text("Quantity") })
    Spacer(Modifier.height(12.dp))
    Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text(button) }
}
