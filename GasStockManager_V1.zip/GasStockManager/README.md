# Gas Stock Manager - Version 1

Single-user offline Android starter app for a gas-cylinder store.

Included:
- Dashboard
- 17 products
- 6 vehicles
- Purchase -> increases store full stock
- Dispatch -> decreases store full stock and increases vehicle full stock
- Return -> records empty returns and updates vehicle/store counts
- English UI
- No server/login required

Open this folder in Android Studio and run the `app` configuration on an Android phone/emulator.
For a production version, the next step should add Room persistence, transaction history, edit/delete, backup, and proper Full/Empty exchange rules.
