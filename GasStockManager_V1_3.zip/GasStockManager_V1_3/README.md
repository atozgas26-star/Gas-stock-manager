# Gas Stock Manager V1.2

Android gas stock manager with offline local storage.

- 17 editable products
- 6 vehicles
- Store Full/Empty stock
- Purchase, Dispatch and Return
- Transaction history and reports
- Data saved locally with SharedPreferences

Build: Gradle 8.9, Android Gradle Plugin 8.7.3, Java 17.
